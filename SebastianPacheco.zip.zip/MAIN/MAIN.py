
import menus

menus.main_menu()
